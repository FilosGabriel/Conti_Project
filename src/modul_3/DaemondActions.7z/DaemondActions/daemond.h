//
// Created by root on 8/5/19.
//

#ifndef IDPS_NEW_DAEMOND_H
#define IDPS_NEW_DAEMOND_H
#include <sys/un.h>
#include <netinet/in.h>
#include "../Log/Notify.h"
#include "../Config/configuration.h"
#include "../Config/Constants.h"
#include "../CommandCenter/command.h"

namespace idps {
//    class Daemond {
//    public:
//
//        void run();
//
//        Daemond(Notify *notify, const Configuration *configuration);
//
//        ~Daemond();
//
//    private:
//        const char *nameFifo = "fifo";
//        bool runn = true;
//        int fd;
//
//        Command *actionCenter;
//        Notify *notify;
//        const Configuration *configuration;
//    };
#define BUFFER_LENGTH    250
    class Daemond {
    public:

        void run();

        Daemond(Notify *notify,  Configuration *configuration);

        ~Daemond();

    private:

        int socketFileDescriptor;
        int message{};
        int port;

        bool running = true;
        sockaddr_in serverAddress{}, clientAddress{};
        Command *actionCenter;
        Notify *notify;
        const Configuration *configuration;
        char buffer[BUFFER_LENGTH];
        struct sockaddr_un serveraddr;
    };
}


#endif //IDPS_NEW_DAEMOND_H
