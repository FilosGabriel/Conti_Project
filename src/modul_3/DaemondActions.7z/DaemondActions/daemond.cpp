//
// Created by root on 8/5/19.
//

#include "daemond.h"

#include <cstdio>
#include <cstring>
#include <unistd.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <iostream>


#include "../Exceptions/fatalError.h"

using namespace idps;
#define SERVER_PATH     "/tmp/server1"

void Daemond::run() {
    socklen_t len;
    while (running) {
        message = recvfrom(socketFileDescriptor, (char *) buffer, 256, 0,
                           (struct sockaddr *) &serveraddr, &len);


        buffer[message] = '\0';
        actionCenter->run(buffer[0] - 48, buffer + 1);
    }
}

Daemond::Daemond(Notify *notify, Configuration *configuration) : port(configuration->getPort()),
                                                                 actionCenter(new Command(notify, configuration)),
                                                                 notify(notify),
                                                                 configuration(configuration) {

    if ((socketFileDescriptor = socket(AF_UNIX, SOCK_DGRAM, 0)) < 0)
        throw FatalError("socket creation failed");

    if (strlen(SERVER_PATH) > sizeof(serveraddr.sun_path) - 1)
        perror("Server socket path too long: %s");

    if (remove(SERVER_PATH) == -1 && errno != ENOENT)
        perror("remove-%s");

    memset(&serveraddr, 0, sizeof(serveraddr));
    serveraddr.sun_family = AF_UNIX;
    strncpy(serveraddr.sun_path, SERVER_PATH, sizeof(serveraddr.sun_path) - 1);


    if (bind(socketFileDescriptor, (struct sockaddr *) &serveraddr, SUN_LEN(&serveraddr)) < 0) {
        std::cerr << "Error :  " << strerror(errno) << std::endl;
        throw FatalError("bind failed daemond");
    }

}

Daemond::~Daemond() {
    close(socketFileDescriptor);
    free(actionCenter);
    free(notify);
}














//
//void Daemond::run() {
//    fd = open(nameFifo, O_RDONLY);
//    char code;
//    char details[SIZE_DETAILS];
//    while (runn) {
//        int length;
//        read(fd, &code, sizeof(code));
//        read(fd, &length, sizeof(int));
//        read(fd, details, sizeof(char) * (length));
//        details[length] = END_OF_STRING;
//        actionCenter->run(code, details);
//    }
//}
//
//Daemond::Daemond(Notify *notify, const Configuration *configuration) :
//        actionCenter(new Command(notify)),
//        notify(notify), configuration(configuration) {
//
//}
//
//Daemond::~Daemond() {
//    close(fd);
//
//}
//
//
