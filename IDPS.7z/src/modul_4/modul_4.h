//
// Created by uic15073 on 8/23/2019.
//

#ifndef MODUL_4_H
#define MODUL_4_H
int modul_4_app();
#endif //IDPS_MODUL_4_H
