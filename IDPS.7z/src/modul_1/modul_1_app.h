//
// Created by uic15073 on 8/23/2019.
//

#ifndef IDPS_MODUL_1_APP_H
#define IDPS_MODUL_1_APP_H
int modul_1_app();
#endif //IDPS_MODUL_1_APP_H
