//
// Created by uic15073 on 9/2/2019.
//

#ifndef IDPS_CONFIGAPP_H
#define IDPS_CONFIGAPP_H

void fileConf();

#endif //IDPS_CONFIGAPP_H
