//
// Created by uic15073 on 9/2/2019.
//

#ifndef IDPS_EXISTSCOMMANDS_H
#define IDPS_EXISTSCOMMANDS_H
bool existCommands();

#endif //IDPS_EXISTSCOMMANDS_H
