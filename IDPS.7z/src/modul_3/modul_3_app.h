//
// Created by uic15073 on 8/28/2019.
//

#ifndef IDPS_MODUL_3_APP_H
#define IDPS_MODUL_3_APP_H
void modul_3_app(int argc,char **argv);
#endif //IDPS_MODUL_3_APP_H
