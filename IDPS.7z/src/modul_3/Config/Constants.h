//
// Created by root on 8/5/19.
//

#ifndef IDPS_NEW_CONSTANTS_H
#define IDPS_NEW_CONSTANTS_H


#define DEFAULT_LOG_FILE  "/var/idps/idps.log"
#define DEFAULT_CONFIG_FILE "/etc/conti_app_conf/m_3/m_3.conf"
#define DEFAULT_FOLDER_LOGS "/var/idps"
#define DEFAULT_ST_FILE "/var/idps/st.csv"





#endif //IDPS_NEW_CONSTANTS_H
