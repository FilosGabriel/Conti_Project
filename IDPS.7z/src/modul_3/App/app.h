//
// Created by root on 8/5/19.
//

#ifndef IDPS_NEW_APP_H
#define IDPS_NEW_APP_H

namespace idps {

    class App {
    public:
        static void start(int argc, char **argv);
    };
}


#endif //IDPS_NEW_APP_H
