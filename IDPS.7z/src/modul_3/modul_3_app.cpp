//
// Created by uic15073 on 8/28/2019.
//

#include <app.h>
#include "modul_3_app.h"

void modul_3_app(int argc, char **argv) {
    idps::App::start(argc, argv);
}
