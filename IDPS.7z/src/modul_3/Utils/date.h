//
// Created by root on 8/5/19.
//

#ifndef IDPS_NEW_DATE_H
#define IDPS_NEW_DATE_H

#include <string>

namespace idps {
    class Date {
    public:
        static const char *getTimeNow();
    };
}


#endif //IDPS_NEW_DATE_H
