//
// Created by root on 8/5/19.
//

#include <sender.h>

using namespace idps;

void NotifySender::sendToServer(std::string message) const {

}