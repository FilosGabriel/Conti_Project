//
// Created by uic15073 on 8/21/2019.
//

#ifndef IDPS_MODUL_2_APP_H
#define IDPS_MODUL_2_APP_H

#include <map>
#include <string>
using  namespace std;
int modul_2_app();
#endif //IDPS_MODUL_2_APP_H
