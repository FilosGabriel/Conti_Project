//
// Created by uic15073 on 8/23/2019.
//

#ifndef MODUL_5_H
#define MODUL_5_H

void modul_5_app(bool terminal);

#endif //IDPS_MODUL_5_H
